package com.capg.exception;

public class ReturnGoodsException extends Exception
{
	public ReturnGoodsException()
	{
		
	}
	public ReturnGoodsException(String msg)
	{
		super(msg);
	}


}
