package com.capg.service;

import java.util.List;

import com.capg.bean.OrderedItem;
import com.capg.bean.Product;
import com.capg.exception.ReturnGoodsException;


public interface ReturnGoodsService 
{

	void updateInventory(String prodId) throws ReturnGoodsException;
	OrderedItem getById(String prodId) throws ReturnGoodsException;
	
}
 
	