package com.capg.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.OrderedItem;
import com.capg.bean.Product;
import com.capg.dao.OrderedItemsDao;
import com.capg.dao.ReturnGoodsDao;
import com.capg.exception.ReturnGoodsException;


@Service
public class ReturnGoodsServiceImp  implements ReturnGoodsService
{
	Product product;
	OrderedItem orditem;

	@Autowired
	ReturnGoodsDao returnGoodsDao;
	
	@Autowired
	OrderedItemsDao orderedItemsDao;

	
	public void updateInventory(String ordId)  {
		orditem = orderedItemsDao.findById(ordId).get();
		Product product=orditem.getProduct();
		String prodId=product.getProdId();
		Product pro=returnGoodsDao.findById(prodId).get();
		
		int qty=pro.getQty();
		
		pro.setQty(qty+1);
	
		returnGoodsDao.save(pro);
		
	}

	
	public OrderedItem getById(String ordId)  {
		// TODO Auto-generated method stub
		orditem = orderedItemsDao.findById(ordId).get();
		orditem.setOrdStatus("RET");
    	orderedItemsDao.save(orditem);	
    	System.out.println(orditem.getOrdId());
    	return orderedItemsDao.findById(ordId).get();
	}

	

	
}
