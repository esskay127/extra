package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.OrderedItem;
import com.capg.exception.ReturnGoodsException;
import com.capg.service.ReturnGoodsService;


@CrossOrigin("http://localhost:4200")
@RestController
public class ReturnGoodsController
{
	@Autowired
	ReturnGoodsService returnGoodsService;
	
	@RequestMapping(value = "ecommerce/186087/returngoods/{ordId}", method = RequestMethod.GET)
	public boolean updateInventory(@PathVariable String ordId)
	{
	  try {
		  returnGoodsService.updateInventory(ordId);
		  returnGoodsService.getById(ordId);
		  return true;
	} catch (Exception e) {
		 System.out.println( e.getMessage());
		 return false;
	}
	}

//	@RequestMapping(value="ecommerce/185756/refund", method = RequestMethod.PUT)
//	public OrderedItem getById(@PathVariable String ordId) throws ReturnGoodsException
//	{
//		return returnGoodsService.getById(ordId);
//	}
}
