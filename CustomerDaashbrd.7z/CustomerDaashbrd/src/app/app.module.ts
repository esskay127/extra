import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule} from '@angular/forms';
import { from } from 'rxjs';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { OrderedItemsComponent } from './ordered-items/ordered-items.component';
import { WalletComponent } from './wallet/wallet.component';
import {  HttpClientModule } from '@angular/common/http';
import { WishlistComponent } from './wishlist/wishlist.component';
import { InboxComponent } from './inbox/inbox.component';
import { SentMailComponent } from './sent-mail/sent-mail.component';
import { MailIndexComponent } from './mail-index/mail-index.component';
import { CartlistComponent } from './cartlist/cartlist.component';
import { ReturndetailsComponent } from './returndetails/returndetails.component';



@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    UpdateProfileComponent,
    OrderedItemsComponent,
    WalletComponent,
    WishlistComponent,
    InboxComponent,
    SentMailComponent,
    MailIndexComponent,
    CartlistComponent,
    ReturndetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
