export class Coupon {
    coupCode: string;
    discount: number;
   }