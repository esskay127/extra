import { Component, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { OrderedItem } from '../ordered-item';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

 private myList: string[];
  constructor(private dashboardService:  DashboardServiceService, private router: Router) { }

  ngOnInit() {
  }

  getOrderedItems(){
// //console.log(custId);
//       this.dashboardService.getOrderedItemsByCustId().subscribe(data=> {
//         this.myList=data
        
//       })
     this.router.navigate(['/orderedItems'])
  }
 

}
  