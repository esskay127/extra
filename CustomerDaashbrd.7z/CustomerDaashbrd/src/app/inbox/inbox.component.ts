import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Email } from '../../Mail';
@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit {
  array: Email[];
  constructor(private mail:MyServiceService) { }

  ngOnInit() {
    this.mail.getInbox().subscribe(data=>this.responseData(data));
  }

  responseData(data){
    this.array=data;
  }

}
