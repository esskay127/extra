

export class Customer {
    custId:string
    emailId:String;
    firstName:String
    lastName:String
    isValid:boolean
    address:String
    phoneNo:number
    walletBalance:number
    
    
//     constructor( custId: string , emailId:String,
//         firstName:String,
//         lastName:String,
//         isValid:String,
//         address:String,
//         phoneNo:number,
//         walletBalance:number){
// this.firstName=firstName;
// this.lastName=lastName;
// this.isValid=true;
// this.address=address;
// this.phoneNo=phoneNo;
// this.walletBalance=walletBalance;
// this.custId=custId;
// }
}
   