import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Email } from '../Mail';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
 
  constructor(private httpClient:HttpClient) { }
  public sendMail(mail:Email):Observable<Email>{
    return this.httpClient.post<Email>("http://localhost:8081/185523/sendemail",mail);
  }

  public getMail(){
    return this.httpClient.get<Email>(`http://localhost:8081/185523/sentbox/customer@gmail.com`);
  }
  
  public getInbox(){
    return this.httpClient.get<Email>("http://localhost:8081/185523/inbox/admin@gmail.com");
  }
}

