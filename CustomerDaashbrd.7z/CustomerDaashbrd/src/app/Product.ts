import { Merchant } from'./merchant';
 
export class Product {
"prodName":string;
"prodCategory":string;
"price":number;
"discount":number;
"validTime":string;
"promoCode":string;
"viewsCount":number;
"qty":number;
"merchant":Merchant;
}

