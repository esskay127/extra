import { Component, OnInit } from '@angular/core';
import { Email } from '../../Mail';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-mail-index',
  templateUrl: './mail-index.component.html',
  styleUrls: ['./mail-index.component.css']
})
export class MailIndexComponent implements OnInit {

  maill: Email;

  constructor(private mail:MyServiceService) { }
  
  sendMail(fromm:string,too:string,maildata:string){
    this.maill=new Email(fromm,too,maildata);
    console.log(fromm);
    this.mail.sendMail(this.maill).subscribe( data => 
      {
    alert('Mail Sent Successfully!');
    });
  }
  ngOnInit() {
  }

}
