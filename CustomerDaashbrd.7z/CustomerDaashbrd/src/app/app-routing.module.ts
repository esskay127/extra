import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OrderedItemsComponent } from './ordered-items/ordered-items.component';
import { WalletComponent } from './wallet/wallet.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { SentMailComponent } from './sent-mail/sent-mail.component';
import { InboxComponent } from './inbox/inbox.component';
import { MailIndexComponent } from './mail-index/mail-index.component';
import { CartlistComponent } from './cartlist/cartlist.component';

const routes: Routes = [ {
 path: "updateProfile",
 component: UpdateProfileComponent 
} ,
{
  path: "dashboard",
  component: DashboardComponent
},
{
  path: "orderedItems",
  component: OrderedItemsComponent
},

{path: "wallet",
component: WalletComponent

},
{
path:"wishlist",
component:WishlistComponent
},

{
  path:'sent',
  component:SentMailComponent
},
{
  path:'inbox',
  component:InboxComponent
},
{
  path:'cartItems',
  component:CartlistComponent
},
{
  path:'mail',
  component:MailIndexComponent
},
 {
  path:'',
  component:DashboardComponent
 },
{
  path:'orderedItems',
  component:OrderedItemsComponent
},
{
  path: "**",
  redirectTo : "dashboard",
  pathMatch: "full"
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
