import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Email } from '../../Mail';
@Component({
  selector: 'app-sent-mail',
  templateUrl: './sent-mail.component.html',
  styleUrls: ['./sent-mail.component.css']
})
export class SentMailComponent implements OnInit {
  message:string="haii";
  array: Email[];
  constructor(private mail:MyServiceService) { }

  ngOnInit() {
    this.mail.getMail().subscribe(data=> {
      this.responseData(data);
    })
  }

  responseData(data){
    this.array=data;
  }
}
