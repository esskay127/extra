export class Email{
    fromMailId:string;
    toMailId:string;
    mail:string;
   constructor(fromMailId:string, toMailId:string,mail:string){
       this.fromMailId=fromMailId;
       this.toMailId=toMailId;
       this.mail=mail;
   }
} 